export const minimed600 = () => {};
