import Foundation
import CoreBluetooth


class Abbott: Transmitter {
    override class var type: DeviceType { DeviceType.transmitter(.abbott) }
    override class var name: String { "Libre" }

    var uid: SensorUid = Data()

    enum UUID: String, CustomStringConvertible, CaseIterable {
        case abbottCustom     = "FDE3"
        case bleLogin         = "F001"
        case compositeRawData = "F002"

        var description: String {
            switch self {
            case .abbottCustom:     return "Abbott custom"
            case .bleLogin:         return "BLE login"
            case .compositeRawData: return "composite raw data"
            }
        }
    }

    override class var knownUUIDs: [String] { UUID.allCases.map{$0.rawValue} }

    override class var dataServiceUUID: String { UUID.abbottCustom.rawValue }
    override class var dataWriteCharacteristicUUID: String { UUID.bleLogin.rawValue }
    override class var dataReadCharacteristicUUID: String  { UUID.compositeRawData.rawValue }


    override func parseManufacturerData(_ data: Data) {
        if data.count > 7 {
            let sensorUid: SensorUid = Data(data[2...7]) + [0x07, 0xe0]
            uid = sensorUid
            main.log("Bluetooth: advertised \(name)'s UID: \(sensorUid.hex)")
        }
    }

    override func read(_ data: Data, for uuid: String) {

        switch UUID(rawValue: uuid) {

        case .compositeRawData:

            // The Libre always sends 46 bytes as three packets of 20 + 18 + 8 bytes

            if data.count == 20 {
                buffer = Data()
                sensor!.lastReadingDate = main.app.lastReadingDate
            }

            buffer.append(data)
            main.log("\(name): partial buffer size: \(buffer.count)")

            if buffer.count == 46 {
                do {
                    let bleData = Data(try Libre2.decryptBLE(id: sensor!.uid, data: buffer))

                    let crc = UInt16(bleData[42...43])
                    let computedCRC = crc16(bleData[0...41])
                    // TODO: detect checksum failure

                    let bleGlucose = sensor!.parseBLEData(bleData)

                    let wearTimeMinutes = Int(UInt16(bleData[40...41]))

                    main.debugLog("Bluetooth: decrypted BLE data: 0x\(bleData.hex), wear time: 0x\(wearTimeMinutes.hex) (\(wearTimeMinutes) minutes, sensor age: \(sensor!.age.formattedInterval)), CRC: \(crc.hex), computed CRC: \(computedCRC.hex), glucose values: \(bleGlucose)")

                    main.log("BLE raw values: \(bleGlucose.map{$0.raw})")

                    // TODO: move UI stuff to MainDelegate()

                    let bleTrend = bleGlucose[0...6].map { factoryGlucose(raw: $0, calibrationInfo: main.settings.activeSensorCalibrationInfo) }
                    let bleHistory = bleGlucose[7...9].map { factoryGlucose(raw: $0, calibrationInfo: main.settings.activeSensorCalibrationInfo) }

                    main.log("BLE temperatures: \((bleTrend + bleHistory).map{Double(String(format: "%.1f", $0.temperature))!})")
                    main.log("BLE factory trend: \(bleTrend.map{$0.value})")
                    main.log("BLE factory history: \(bleHistory.map{$0.value})")

                    main.history.rawTrend = sensor!.trend
                    let factoryTrend = sensor!.factoryTrend
                    main.history.factoryTrend = factoryTrend
                    main.log("BLE merged trend: \(factoryTrend.map{$0.value})".replacingOccurrences(of: "-1", with: "… "))

                    // TODO: compute accurate delta and update trend arrow
                    let deltaMinutes = factoryTrend[6].value != 0 ? 6 : 7
                    let delta = (factoryTrend[0].value != 0 ? factoryTrend[0].value : (factoryTrend[1].value != 0 ? factoryTrend[1].value : factoryTrend[2].value)) - factoryTrend[deltaMinutes].value
                    main.app.trendDeltaMinutes = deltaMinutes
                    main.app.trendDelta = delta


                    main.history.rawValues = sensor!.history
                    let factoryHistory = sensor!.factoryHistory
                    main.history.factoryValues = factoryHistory
                    main.log("BLE merged history: \(factoryHistory.map{$0.value})".replacingOccurrences(of: "-1", with: "… "))

                    // Slide the OOP history
                    // TODO: apply the following also after a NFC scan
                    let historyDelay = 2
                    if (wearTimeMinutes - historyDelay) % 15 == 0 || wearTimeMinutes - sensor!.history[1].id > 16 {
                        if main.history.values.count > 0 {
                            let missingCount = (sensor!.history[0].id - main.history.values[0].id) / 15
                            var history = [Glucose](main.history.rawValues.prefix(missingCount) + main.history.values.prefix(32 - missingCount))
                            for i in 0 ..< missingCount { history[i].value = -1 }
                            main.history.values = history
                        }
                    }

                    main.applyCalibration(sensor: sensor)

                    // TODO: complete backfill

                    main.status("\(sensor!.type)  +  BLE")

                } catch {
                    // TODO: verify crc16
                    main.log(error.localizedDescription)
                    main.errorStatus(error.localizedDescription)
                    buffer = Data()
                }
            }

        default:
            break
        }
    }

}
