import Foundation
import Combine
import AVFoundation


// https://fortinetweb.s3.amazonaws.com/fortiguard/research/techreport.pdf
// https://github.com/travisgoodspeed/goodtag/wiki/RF430TAL152H
// https://github.com/travisgoodspeed/GoodV/blob/master/app/src/main/java/com/kk4vcz/goodv/NfcRF430TAL.java
// https://github.com/cryptax/misc-code/blob/master/glucose-tools/readdump.py
// https://github.com/travisgoodspeed/goodtag/blob/master/firmware/gcmpatch.c
// https://github.com/captainbeeheart/openfreestyle/blob/master/docs/reverse.md


struct NFCCommand {
    let code: Int
    var parameters: Data = Data()
    var description: String { "" }
}


extension Sensor {

    var backdoor: Data {
        switch self.type {
        case .libre1:    return Data([0xc2, 0xad, 0x75, 0x21])
        case .libreProH: return Data([0xc2, 0xad, 0x00, 0x90])
        default:         return Data([0xde, 0xad, 0xbe, 0xef])
        }
    }

    var activationCommand: NFCCommand {
        switch self.type {
        case .libre1,
             .libreProH: return NFCCommand(code: 0xA0, parameters: backdoor)
        case .libre2:    return nfcCommand(.activate)
        default:         return NFCCommand(code: 0x00)
        }
    }

    var universalCommand: NFCCommand   { NFCCommand(code: 0xA1) }

    // Libre 1
    var lockCommand: NFCCommand        { NFCCommand(code: 0xA2, parameters: backdoor) }
    var readRawCommand: NFCCommand     { NFCCommand(code: 0xA3, parameters: backdoor) }
    var unlockCommand: NFCCommand      { NFCCommand(code: 0xA4, parameters: backdoor) }

    // Libre 2 / Pro
    // SEE: custom commands C0-C4 in TI RF430FRL15xH Firmware User's Guide
    var readBlockCommand: NFCCommand   { NFCCommand(code: 0xB0) }
    var readBlocksCommand: NFCCommand  { NFCCommand(code: 0xB3) }

    /// replies with error 0x12 (.contentCannotBeChanged)
    var writeBlockCommand: NFCCommand  { NFCCommand(code: 0xB1) }

    /// replies with errors 0x12 (.contentCannotBeChanged) or 0x0f (.unknown)
    /// writing three blocks is not supported because it exceeds the 32-byte input buffer
    var writeBlocksCommand: NFCCommand { NFCCommand(code: 0xB4) }

    /// Usual 1252 blocks limit:
    /// block 04e3 => error 0x11 (.blockAlreadyLocked)
    /// block 04e4 => error 0x10 (.blockNotAvailable)
    var lockBlockCommand: NFCCommand   { NFCCommand(code: 0xB2) }


    enum Subcommand: UInt8, CustomStringConvertible {
        case unlock          = 0x1a    // lets read FRAM in clear and dump further blocks with B0/B3
        case activate        = 0x1b
        case enableStreaming = 0x1e
        case unknown0x10     = 0x10    // returns the number of parameters + 3
        case unknown0x1c     = 0x1c
        case unknown0x1d     = 0x1d    // disables Bluetooth
        case unknown0x1f     = 0x1f    // unknown secret, GEN_SECURITY_CMD_GET_SESSION_INFO
        // TODO: test
        case readChallenge   = 0x20    // GEN_SECURITY_CMD_SECURITY_CHALLENGE
        case readBlocks      = 0x21
        case readAttribute   = 0x22

        var description: String {
            switch self {
            case .unlock:          return "unlock"
            case .activate:        return "activate"
            case .enableStreaming: return "enable BLE streaming"
            case .readBlocks:      return "read FRAM blocks"
            default:               return "[unknown: 0x\(rawValue.hex)]"
            }
        }
    }


    /// The customRequestParameters for 0xA1 are built by appending
    /// code + params (b) + usefulFunction(uid, code, secret (y))
    func nfcCommand(_ code: Subcommand) -> NFCCommand {

        var parameters = Data([code.rawValue])

        var b: [UInt8] = []
        var y: UInt16 = 0x1b6a

        if code == .enableStreaming {

            // Enables Bluetooth on Libre 2. Returns peripheral MAC address to connect to.
            // unlockCode could be any 32 bit value. The unlockCode and sensor Uid / patchInfo
            // will have also to be provided to the login function when connecting to peripheral.

            b = [
                UInt8(unlockCode & 0xFF),
                UInt8((unlockCode >> 8) & 0xFF),
                UInt8((unlockCode >> 16) & 0xFF),
                UInt8((unlockCode >> 24) & 0xFF)
            ]
            y = UInt16(patchInfo[4...5]) ^ UInt16(b[1], b[0])
        }

        if b.count > 0 {
            parameters += b
        }

        let d = Libre2.usefulFunction(id: uid, x: UInt16(code.rawValue), y: y)
        parameters += d

        return NFCCommand(code: 0xA1, parameters: parameters)
    }
}


#if !os(watchOS)

import CoreNFC


// TODO

enum IS015693Error: Int, CustomStringConvertible {
    case none                 = 0x00
    case commandNotSupported  = 0x01
    case commandNotRecognized = 0x02
    case optionNotSupported   = 0x03
    case unknown              = 0x0f
    case blockNotAvailable    = 0x10
    case blockAlreadyLocked   = 0x11
    case contentCannotBeChanged = 0x12

    var description: String {
        switch self {
        case .none:                 return "none"
        case .commandNotSupported:  return "command not supported"
        case .commandNotRecognized: return "command not recognized (e.g. format error)"
        case .optionNotSupported:   return "option not supported"
        case .unknown:              return "unknown"
        case .blockNotAvailable:    return "block not available (out of range, doesn’t exist)"
        case .blockAlreadyLocked:   return "block already locked -- can’t be locked again"
        case .contentCannotBeChanged: return "block locked -- content cannot be changed"
        }
    }
}


extension Error {
    var iso15693Code: Int {
        if let code = (self as NSError).userInfo[NFCISO15693TagResponseErrorKey] as? Int {
            return code
        } else {
            return 0
        }
    }
    var iso15693Description: String { IS015693Error(rawValue: self.iso15693Code)?.description ?? "[code: 0x\(self.iso15693Code.hex)]" }
}


// https://github.com/ivalkou/LibreTools/blob/master/Sources/LibreTools/NFC/NFCManager.swift

// TODO: refactor using Combine or, better, the upcoming await/async

enum TaskRequest {
    case activate
    case enableStreaming
    case readFRAM
    case unlock
    case dump
}

class NFC: NSObject, NFCTagReaderSessionDelegate {

    var tagSession: NFCTagReaderSession?
    var connectedTag: NFCISO15693Tag?
    var sensor: Sensor!

    var taskRequest: TaskRequest? {
        didSet {
            guard taskRequest != nil else { return }
            startSession()
        }
    }

    /// Main app delegate to use its log()
    var main: MainDelegate!

    var isAvailable: Bool {
        return NFCTagReaderSession.readingAvailable
    }

    func startSession() {
        // execute in the .main queue because of publishing changes to main's observables
        tagSession = NFCTagReaderSession(pollingOption: [.iso15693], delegate: self, queue: .main)
        tagSession?.alertMessage = "Hold the top of your iPhone near the Libre sensor until the second longer vibration"
        tagSession?.begin()
    }

    public func tagReaderSessionDidBecomeActive(_ session: NFCTagReaderSession) {
        main.log("NFC: session did become active")
    }

    public func tagReaderSession(_ session: NFCTagReaderSession, didInvalidateWithError error: Error) {
        if let readerError = error as? NFCReaderError {
            if readerError.code != .readerSessionInvalidationErrorUserCanceled {
                session.invalidate(errorMessage: "Connection failure: \(readerError.localizedDescription)")
                main.log("NFC: \(readerError.localizedDescription)")
            }
        }
    }

    public func tagReaderSession(_ session: NFCTagReaderSession, didDetect tags: [NFCTag]) {
        main.log("NFC: did detect tags")

        guard let firstTag = tags.first else { return }
        guard case .iso15693(let tag) = firstTag else { return }

        session.alertMessage = "Scan Complete"

        session.connect(to: firstTag) { error in
            if error != nil {
                self.main.log("NFC: \(error!.localizedDescription)")
                session.invalidate(errorMessage: "Connection failure: \(error!.localizedDescription)")
                return
            }
            self.connectedTag = tag

            // https://www.st.com/en/embedded-software/stsw-st25ios001.html#get-software

            #if !targetEnvironment(macCatalyst)    // the new Result handlers don't compile in Catalyst 14

            self.connectedTag?.getSystemInfo(requestFlags: .highDataRate) { result in

                // "pop" vibration
                AudioServicesPlaySystemSound(1520)

                var systemInfo: NFCISO15693SystemInfo

                switch result {

                case .failure(let error):
                    session.invalidate(errorMessage: "Error while getting system info: " + error.localizedDescription)
                    self.main.log("NFC: error while getting system info: \(error.localizedDescription)")
                    return

                case .success(let data):
                    systemInfo = data
                }

                if  self.main.app.sensor != nil {
                    self.sensor = self.main.app.sensor
                } else {
                    self.sensor = Sensor(main: self.main)
                    self.main.app.sensor = self.sensor
                }

                self.connectedTag?.customCommand(requestFlags: .highDataRate, customCommandCode: 0xA1, customRequestParameters: Data()) { result in

                    var patchInfo = Data()

                    switch result {

                    case .failure(let error):
                        self.main.log("NFC: error while getting patch info: \(error.localizedDescription)")

                    case .success(let data):
                        patchInfo = data
                    }

                    let uid = self.connectedTag!.identifier.hex
                    self.main.log("NFC: IC identifier: \(uid)")

                    var manufacturer = String(tag.icManufacturerCode)
                    if manufacturer == "7" {
                        manufacturer.append(" (Texas Instruments)")
                    }
                    self.main.log("NFC: IC manufacturer code: \(manufacturer)")
                    self.main.log("NFC: IC serial number: \(tag.icSerialNumber.hex)")

                    var rom = "RF430"
                    switch self.connectedTag?.identifier[2] {
                    case 0xA0: rom += "TAL152H Libre 1 A0"
                    case 0xA4: rom += "TAL160H Libre 2 A4"
                    default:   rom += " unknown"
                    }
                    self.main.log("NFC: \(rom) ROM")

                    self.main.log(String(format: "NFC: IC reference: 0x%X", systemInfo.icReference))
                    if systemInfo.applicationFamilyIdentifier != -1 {
                        self.main.log(String(format: "NFC: application family id (AFI): %d", systemInfo.applicationFamilyIdentifier))
                    }
                    if systemInfo.dataStorageFormatIdentifier != -1 {
                        self.main.log(String(format: "NFC: data storage format id: %d", systemInfo.dataStorageFormatIdentifier))
                    }

                    self.main.log(String(format: "NFC: memory size: %d blocks", systemInfo.totalBlocks))
                    self.main.log(String(format: "NFC: block size: %d", systemInfo.blockSize))

                    self.sensor.uid = Data(tag.identifier.reversed())
                    self.main.log("NFC: sensor uid: \(self.sensor.uid.hex)")

                    self.sensor.patchInfo = Data(patchInfo)
                    if patchInfo.count > 0 {
                        self.main.log("NFC: patch info: \(patchInfo.hex)")
                        self.main.log("NFC: sensor type: \(self.sensor.type.rawValue)")

                        self.main.settings.patchUid = self.sensor.uid
                        self.main.settings.patchInfo = self.sensor.patchInfo
                    }

                    self.main.log("NFC: sensor serial number: \(self.sensor.serial)")

                    if self.taskRequest != .none {

                        /// Libre 1 memory layout:
                        /// config: 0x1A00, 64    (sensor UID and calibration info)
                        /// sram:   0x1C00, 512
                        /// rom:    0x4400 - 0x5FFF
                        /// fram lock table: 0xF840, 32
                        /// fram:   0xF860, 1952

                        if self.taskRequest == .dump {

                            self.readRaw(0x1A00, 64) { address, data, error in
                                if error == nil {
                                    self.main.log(data.hexDump(header: "Config RAM (patch UID at 0x1A08):", address: address))
                                }

                                self.readRaw(0x1C00, 512) { address, data, error in
                                    if error == nil {
                                        self.main.log(data.hexDump(header: "SRAM:", address: address))
                                    }

                                    self.readRaw(0xFFAC, 36) { address, data, error in
                                        if error == nil {
                                            self.main.log(data.hexDump(header: "Patch table for A0-A4 E0-E2 commands:", address: address))
                                        }

                                        self.readRaw(0xF860, 43 * 8) { address, data, error in
                                            if error == nil {
                                                self.main.log(data.hexDump(header: "FRAM:", address: address))
                                            }

                                            self.read(from: 0, count: 43) { start, data, error in
                                                if error == nil {
                                                    self.main.log(data.hexDump(header: "ISO 15693 FRAM blocks:", startingBlock: start))
                                                    if data.count > 0 {
                                                        self.sensor.fram = Data(data)
                                                    }
                                                    if self.sensor.encryptedFram.count > 0 && self.sensor.fram.count >= 344 {
                                                        self.main.log("\(self.sensor.fram.hexDump(header: "Decrypted FRAM:", startingBlock: 0))")
                                                    }
                                                }


                                                // self.main.app.lastReadingDate = Date()
                                                // self.sensor.lastReadingDate = self.main.app.lastReadingDate
                                                // self.main.parseSensorData(self.sensor)


                                                /// count is limited to 89 with an encrypted sensor (header as first 3 blocks);
                                                /// after sending the A1 1A subcommand the FRAM is decrypted in-place
                                                /// and mirrored in the last 43 blocks of 89 but the max count becomes 1252
                                                self.readBlocks(from: 0, count: 1252) { start, data, error in

                                                    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)

                                                    let blocks = data.count / 8

                                                    self.main.log(data.hexDump(header: "B0/B3 command output (\(blocks) blocks):", startingBlock: start))
                                                    if error != nil {
                                                        self.main.log("NFC: \(error!.localizedDescription) (ISO 15693 error 0x\(error!.iso15693Code.hex): \(error!.iso15693Description))")
                                                    }


                                                    // self.writeRaw(0xFFB8, Data([0xE0, 0x00])) { // to restore: Data([0xAB, 0xAB]))
                                                    // TODO: overwrite commands CRC
                                                    // self.main.log("NFC: did write at address: 0x\($0.hex), bytes: 0x\($1.hex), error: \($2?.localizedDescription ?? "none")")
                                                    // } // TEST writeRaw


                                                    self.taskRequest = .none
                                                    session.invalidate()


                                                    if error == nil && self.main.settings.debugLevel > 0 {
                                                        let bytes = min(89 * 8 + 34 + 10, data.count)
                                                        var offset = 0
                                                        var i = offset + 2
                                                        while offset < bytes - 3 && i < bytes - 1 {
                                                            if UInt16(data[offset ... offset + 1]) == data[offset + 2 ... i + 1].crc16 {
                                                                self.main.log("CRC matches for \(i - offset + 2) bytes at #\((offset / 8).hex) [\(offset + 2)...\(i + 1)] \(data[offset ... offset + 1].hex) = \(data[offset + 2 ... i + 1].crc16.hex)\n\(data[offset ... i + 1].hexDump(header: "\(self.libre2DumpMap[offset]?.1 ?? "[???]"):", address: 0))")
                                                                offset = i + 2
                                                                i = offset
                                                            }
                                                            i += 2
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            return
                        }

                        libre2:
                        if self.sensor.type == .libre2 {
                            let subCmd: Sensor.Subcommand = (self.taskRequest == .enableStreaming) ?
                                .enableStreaming : (self.taskRequest == .activate) ?
                                .activate : (self.taskRequest == .unlock) ?
                                .unlock :.unknown0x1c

                            // TODO
                            if subCmd == .unknown0x1c { break libre2 }

                            let currentUnlockCode = self.sensor.unlockCode
                            self.sensor.unlockCode = UInt32(self.main.settings.activeSensorUnlockCode)

                            let cmd = self.sensor.nfcCommand(subCmd)
                            self.main.log("NFC: sending \(self.sensor.type) command to \(subCmd.description): code: 0x\(cmd.code.hex), parameters: 0x\(cmd.parameters.hex)")
                            self.connectedTag?.customCommand(requestFlags: .highDataRate, customCommandCode: cmd.code, customRequestParameters:  cmd.parameters) { result in

                                AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)

                                switch result {

                                case .failure(let error):
                                    self.main.log("NFC: '\(subCmd.description)' command error: \(error.localizedDescription) (ISO 15693 error 0x\(error.iso15693Code.hex): \(error.iso15693Description))")
                                    self.sensor.unlockCode = currentUnlockCode

                                case.success(let output):
                                    self.main.log("NFC: '\(subCmd.description)' command output (\(output.count) bytes): 0x\(output.hex)")

                                    if subCmd == .enableStreaming && output.count == 6 {
                                        self.main.log("NFC: enabled BLE streaming on \(self.sensor.type) \(self.sensor.serial) (unlock code: \(self.sensor.unlockCode), MAC address: \(Data(output.reversed()).hexAddress))")
                                        self.main.settings.activeSensorSerial = self.sensor.serial
                                        self.main.settings.activeSensorAddress = Data(output.reversed())
                                        self.sensor.activePatchInfo = self.sensor.patchInfo
                                        self.main.settings.activeSensorPatchInfo = self.sensor.patchInfo
                                        self.sensor.unlockCount = 0
                                        self.main.settings.activeSensorUnlockCount = 0

                                        // TODO: cancel connections also before enabling streaming?
                                        self.main.rescan()

                                    }

                                    if subCmd == .activate && output.count == 4 {
                                        self.main.log("NFC: after trying activating received \(output.hex) for the patch info \(patchInfo.hex)")
                                        // receiving 9d081000 for a patchInfo 9d0830010000
                                    }

                                    if subCmd == .unlock && output.count == 0 {
                                        self.main.log("NFC: FRAM should have been decrypted in-place")
                                        // TODO: test
                                    }
                                }

                                self.taskRequest = .none
                                // session.invalidate()
                            }
                        }
                        
                    }

                    var blocks = 43
                    if self.taskRequest == .readFRAM {
                        if self.sensor.type == .libre1 {
                            blocks = 244
                        }
                    }

                    self.read(from: 0, count: blocks) { start, data, error in

                        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)

                        if error == nil {
                            session.invalidate()
                        }

                        self.main.log(data.hexDump(header: "NFC: did read \(data.count / 8) FRAM blocks:", startingBlock: 0))

                        self.main.app.lastReadingDate = Date()
                        self.sensor.lastReadingDate = self.main.app.lastReadingDate

                        if data.count > 0 {
                            self.sensor.fram = Data(data)
                        }

                        if self.taskRequest == .readFRAM {
                            self.sensor.detailFRAM()
                            self.taskRequest = .none
                            return
                        }

                        self.main.parseSensorData(self.sensor)

                        self.main.status("\(self.sensor.type)  +  NFC")
                    }
                }
            }

            #endif
        }
    }

    #if !targetEnvironment(macCatalyst)    // the new Result handlers don't compile in Catalyst 14


    func read(from start: Int, count blocks: Int, requesting: Int = 3, retries: Int = 5, buffer: Data = Data(), handler: @escaping (Int, Data, Error?) -> Void) {

        var buffer = buffer
        let blockToRead = start + buffer.count / 8

        var remaining = blocks
        var requested = requesting
        var retries = retries

        // FIXME: "Feature not supported" error
        //        self.connectedTag?.readMultipleBlock(readConfiguration: NFCISO15693ReadMultipleBlocksConfiguration(range: NSRange(blockToRead ... blockToRead + requested - 1), chunkSize: 8, maximumRetries: 5, retryInterval: 0.1)) { data, error in
        //            self.main.log("NFC: error while reading multiple blocks #\(blockToRead) - #\(blockToRead + requested - 1): \(error!) (ISO 15693 error 0x\(error!.iso15693Code.hex): \(error!.iso15693Description))")
        //        }
        //        self.connectedTag?.sendCustomCommand(commandConfiguration: NFCISO15693CustomCommandConfiguration(manufacturerCode: 7, customCommandCode: 0xA1, requestParameters: Data(), maximumRetries: 5, retryInterval: 0.1)) { data, error in
        //            self.main.log("NFC: custom command output: \(data.hex), error: \(error!) (ISO 15693 error 0x\(error!.iso15693Code.hex): \(error!.iso15693Description))")
        //        }

        self.connectedTag?.readMultipleBlocks(requestFlags: .highDataRate,
                                              blockRange: NSRange(blockToRead ... blockToRead + requested - 1)) { result in
            switch result {

            case .failure(let error):
                self.main.log("NFC: error while reading multiple blocks #\(blockToRead) - #\(blockToRead + requested - 1): \(error.localizedDescription) (ISO 15693 error 0x\(error.iso15693Code.hex): \(error.iso15693Description))")
                if retries > 0 {
                    retries -= 1
                    self.main.log("NFC: retry # \(5 - retries)...")
                    usleep(100000)
                    AudioServicesPlaySystemSound(1520)    // "pop" vibration
                    self.read(from: start, count: remaining, requesting: requested, retries: retries, buffer: buffer) { start, data, error in handler(start, data, error) }

                } else {
                    self.tagSession?.invalidate(errorMessage: "Error while reading multiple blocks: \(error.localizedDescription.localizedLowercase)")
                    handler(start, buffer, error)
                }

            case.success(let dataArray):

                for data in dataArray {
                    buffer += data
                }

                remaining -= requested

                let error: Error? = nil
                if remaining == 0 {
                    handler(start, buffer, error)

                } else {
                    if remaining < requested {
                        requested = remaining
                    }
                    self.read(from: start, count: remaining, requesting: requested, buffer: buffer) { start, data, error in handler(start, data, error) }
                }
            }
        }
    }


    let libre2DumpMap = [
        0x000:  (40,  "Extended header"),
        0x028:  (32,  "Extended footer"),
        0x048:  (296, "Body right rotated by 4"),
        0x170:  (24,  "FRAM header"),
        0x188:  (296, "FRAM body"),
        0x2b0:  (24,  "FRAM footer"),
        0x2c8:  (34,  "Keys"),
        0x2ea:  (10,  "MAC Address"),
        0x26d8: (24,  "Table of enabled NFC commands")
    ]

    // 0x2580: (4, "Libre 1 backdoor")

    // 0c8a  CMP.W  #0xadc2, &RF13MRXF
    // 0c90  JEQ  0c96
    // 0c92  MOV.B  #0, R12
    // 0c94  RET
    // 0c96  CMP.W  #0x2175, &RF13MRXF
    // 0c9c  JNE  0c92
    // 0c9e  MOV.B  #1, R12
    // 0ca0  RET

    // function at 24e2:
    //    if (param_1 == '\x1e') {
    //      param_3 = param_3 ^ param_4;
    //    }
    //    else {
    //      param_3 = 0x1b6a;
    //    }

    // 0800: RF13MCTL
    // 0802: RF13MINT
    // 0804: RF13MIV
    // 0806: RF13MRXF
    // 0808: RF13MTXF
    // 080a: RF13MCRC
    // 080c: RF13MFIFOFL
    // 080e: RF13MWMCFG

    func readBlocks(from start: Int, count blocks: Int, requesting: Int = 3, buffer: Data = Data(), handler: @escaping (Int, Data, Error?) -> Void) {

        if sensor.type != .libre2 {
            handler(start, buffer, NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "readBlocks() B3 command not supported by \(sensor.type)"]))
            return
        }

        var buffer = buffer
        let blockToRead = start + buffer.count / 8

        var remaining = blocks
        var requested = requesting

        var readCommand = NFCCommand(code: 0xB3, parameters: Data([UInt8(blockToRead & 0xFF), UInt8(blockToRead >> 8), UInt8(requested - 1)]))
        if requested == 1 {
            readCommand = NFCCommand(code: 0xB0, parameters: Data([UInt8(blockToRead & 0xFF), UInt8(blockToRead >> 8)]))
        }

        if buffer.count == 0 { self.main.debugLog("NFC: sending \(readCommand.code.hex) 07 \(readCommand.parameters.hex) command (\(sensor.type) read blocks)") }

        self.connectedTag?.customCommand(requestFlags: .highDataRate, customCommandCode: readCommand.code, customRequestParameters: readCommand.parameters) { result in

            switch result {

            case .failure(let error):
                if requested == 1 {
                    self.main.log("NFC: error while reading block #\(blockToRead): \(error.localizedDescription) (ISO 15693 error 0x\(error.iso15693Code.hex): \(error.iso15693Description))")
                } else {
                    self.main.log("NFC: error while reading multiple blocks #\(blockToRead.hex) - #\((blockToRead + requested - 1).hex) (\(blockToRead)-\(blockToRead + requested - 1)): \(error.localizedDescription) (ISO 15693 error 0x\(error.iso15693Code.hex): \(error.iso15693Description))")
                }

                handler(start, buffer, error)

            case.success(let data):

                buffer += data
                remaining -= requested

                let error: Error? = nil
                if remaining == 0 {
                    handler(start, buffer, error)
                } else {
                    if remaining < requested {
                        requested = remaining
                    }
                    self.readBlocks(from: start, count: remaining, requesting: requested, buffer: buffer) { start, data, error in handler(start, data, error) }
                }
            }
        }
    }


    // Libre 1 only

    func readRaw(_ address: Int, _ bytes: Int, buffer: Data = Data(), handler: @escaping (Int, Data, Error?) -> Void) {

        if sensor.type != .libre1 && sensor.type != .libreUS14day {
            handler(address, buffer, NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "readRaw() A3 command not supported by \(sensor.type)"]))
            return
        }

        var buffer = buffer
        let addressToRead = address + buffer.count

        var remainingBytes = bytes
        let bytesToRead = remainingBytes > 24 ? 24 : bytes

        var remainingWords = bytes / 2
        if bytes % 2 == 1 || ( bytes % 2 == 0 && addressToRead % 2 == 1 ) { remainingWords += 1 }
        let wordsToRead = remainingWords > 12 ? 12 : remainingWords    // real limit is 15

        let readRawCommand = NFCCommand(code: 0xA3, parameters: self.sensor.backdoor + [UInt8(addressToRead & 0xFF), UInt8(addressToRead >> 8), UInt8(wordsToRead)])

        if buffer.count == 0 { self.main.debugLog("NFC: sending \(readRawCommand.code.hex) 07 \(readRawCommand.parameters.hex) command (\(sensor.type) read raw)") }

        self.connectedTag?.customCommand(requestFlags: .highDataRate, customCommandCode: readRawCommand.code, customRequestParameters: readRawCommand.parameters) { result in

            switch result {

            case .failure(let error):
                self.main.debugLog("NFC: error while reading \(wordsToRead) words at raw memory 0x\(addressToRead.hex): \(error.localizedDescription) (ISO 15693 error 0x\(error.iso15693Code.hex): \(error.iso15693Description))")
                handler(address, buffer, error)

            case.success(var data):

                if addressToRead % 2 == 1 { data = data.subdata(in: 1 ..< data.count) }
                if data.count - bytesToRead == 1 { data = data.subdata(in: 0 ..< data.count - 1) }

                buffer += data
                remainingBytes -= data.count

                let error: Error? = nil
                if remainingBytes == 0 {
                    handler(address, buffer, error)
                } else {
                    self.readRaw(address, remainingBytes, buffer: buffer) { address, data, error in handler(address, data, error) }
                }
            }
        }
    }


    // Libre 1 only: overwrite mirrored FRAM blocks

    func writeRaw(_ address: Int, _ data: Data, handler: @escaping (Int, Data, Error?) -> Void) {

        if sensor.type != .libre1 && sensor.type != .libreUS14day {
            handler(address, Data(), NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "writeRaw() not supported by \(sensor.type)"]))
            return
        }

        // Unlock
        self.main.debugLog("NFC: sending a4 07 \(sensor.backdoor.hex) command (\(sensor.type) unlock)")
        self.connectedTag?.customCommand(requestFlags: .highDataRate, customCommandCode: 0xA4, customRequestParameters: self.sensor.backdoor) { result in

            switch result {

            case .failure(let commandError):
                self.main.debugLog("NFC: unlock command error: \(commandError.localizedDescription)")

            case.success(let output):
                self.main.debugLog("NFC: unlock command output: 0x\(output.hex)")
            }

            let addressToRead = (address / 8) * 8
            let startOffset = address % 8
            let endAddressToRead = ((address + data.count - 1) / 8) * 8 + 7
            let blocksToRead = (endAddressToRead - addressToRead) / 8 + 1

            self.readRaw(addressToRead, blocksToRead * 8) {

                readAddress, readData, error in

                var msg = error?.localizedDescription ?? readData.hexDump(header: "NFC: blocks to overwrite:", address: readAddress)

                if error != nil {
                    handler(address, data, error)
                    return
                }

                var bytesToWrite = readData
                bytesToWrite.replaceSubrange(startOffset ..< startOffset + data.count, with: data)
                msg += "\(bytesToWrite.hexDump(header: "\nwith blocks:", address: addressToRead))"
                self.main.debugLog(msg)

                let startBlock = addressToRead / 8
                let blocks = bytesToWrite.count / 8

                if address >= 0xF860 {    // write to FRAM blocks

                    let requestBlocks = 2    // 3 doesn't work

                    let requests = Int(ceil(Double(blocks) / Double(requestBlocks)))
                    let remainder = blocks % requestBlocks
                    var blocksToWrite = [Data](repeating: Data(), count: blocks)

                    for i in 0 ..< blocks {
                        blocksToWrite[i] = Data(bytesToWrite[i * 8 ... i * 8 + 7])
                    }

                    for i in 0 ..< requests {

                        let startIndex = startBlock - 0xF860 / 8 + i * requestBlocks
                        let endIndex = startIndex + (i == requests - 1 ? (remainder == 0 ? requestBlocks : remainder) : requestBlocks) - (requestBlocks > 1 ? 1 : 0)
                        let blockRange = NSRange(startIndex ... endIndex)

                        var dataBlocks = [Data]()
                        for j in startIndex ... endIndex { dataBlocks.append(blocksToWrite[j - startIndex]) }

                        self.connectedTag?.writeMultipleBlocks(requestFlags: .highDataRate, blockRange: blockRange, dataBlocks: dataBlocks) {

                            error in

                            if error != nil {
                                self.main.log("NFC: error while writing multiple blocks 0x\(startIndex.hex)-0x\(endIndex.hex) \(dataBlocks.reduce("", { $0 + $1.hex })) at 0x\(((startBlock + i * requestBlocks) * 8).hex): \(error!.localizedDescription)")
                                if i != requests - 1 { return }

                            } else {
                                self.main.debugLog("NFC: wrote blocks 0x\(startIndex.hex) - 0x\(endIndex.hex) \(dataBlocks.reduce("", { $0 + $1.hex })) at 0x\(((startBlock + i * requestBlocks) * 8).hex)")
                            }

                            if i == requests - 1 {

                                // Lock
                                self.connectedTag?.customCommand(requestFlags: .highDataRate, customCommandCode: 0xA2, customRequestParameters: self.sensor.backdoor) { result in

                                    var error: Error? = nil

                                    switch result {

                                    case .failure(let commandError):
                                        self.main.debugLog("NFC: lock command error: \(commandError.localizedDescription)")
                                        error = commandError

                                    case.success(let output):
                                        self.main.debugLog("NFC: lock command output: 0x\(output.hex)")
                                    }

                                    handler(address, data, error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    #endif    // !targetEnvironment(macCatalyst)

}

#endif    // !os(watchOS)
